import sqlite3
import pandas as pd

# Create an in-memory database
conn = sqlite3.connect(":memory:")
cursor = conn.cursor()

# Create the EquipmentTransactions table
cursor.execute("""
CREATE TABLE EquipmentTransactions (
    id INTEGER,
    type TEXT
)
""")

# Insert example data
data = [
    (1, 'sale'),
    (2, 'rent'),
    (3, 'sale'),
    (4, 'rent'),
    (5, 'rent')
]

cursor.executemany("INSERT INTO EquipmentTransactions VALUES (?, ?)", data)

# Run SQL query to count sales vs rentals
query = """
SELECT type, COUNT(*) as total
FROM EquipmentTransactions
GROUP BY type
"""

report = pd.read_sql(query, conn)

# Show result
print("Equipment Sales vs Rentals Report")
print(report)
