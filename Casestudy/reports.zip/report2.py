import sqlite3
import pandas as pd

# Create an in-memory database
conn = sqlite3.connect(":memory:")
cursor = conn.cursor()

# Create the Bookings table
cursor.execute("""
CREATE TABLE Bookings (
    id INTEGER,
    region TEXT,
    date TEXT
)
""")

# Insert example data
data = [
    (1, 'Africa', '2022-05-10'),
    (2, 'Asia', '2023-06-15'),
    (3, 'Southern Europe', '2023-07-20'),
    (4, 'Africa', '2024-01-11'),
    (5, 'Asia', '2024-03-30'),
    (6, 'Africa', '2025-01-05')
]

cursor.executemany("INSERT INTO Bookings VALUES (?, ?, ?)", data)

# Run SQL query to get bookings by region and year
query = """
SELECT region, strftime('%Y', date) AS year, COUNT(*) as total
FROM Bookings
GROUP BY region, year
ORDER BY region, year
"""

report = pd.read_sql(query, conn)

# Show result
print("Booking Trends by Region")
print(report)
