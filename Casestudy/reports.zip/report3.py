import sqlite3
import pandas as pd
import datetime

# Create in-memory database
conn = sqlite3.connect(":memory:")
cursor = conn.cursor()

# Create the Inventory table
cursor.execute("""
CREATE TABLE Inventory (
    id INTEGER,
    name TEXT,
    purchase_date TEXT
)
""")

# Insert example data
data = [
    (1, 'Tent', '2018-04-01'),
    (2, 'Backpack', '2020-06-15'),
    (3, 'Stove', '2017-09-10'),
    (4, 'Lantern', '2023-01-25'),
    (5, 'Sleeping Bag', '2016-02-18')
]

cursor.executemany("INSERT INTO Inventory VALUES (?, ?, ?)", data)

# Calculate cutoff date (5 years ago from today)
cutoff_date = (datetime.datetime.now() - datetime.timedelta(days=5*365)).strftime('%Y-%m-%d')

# SQL to find items older than 5 years
query = f"""
SELECT * FROM Inventory
WHERE purchase_date <= '{cutoff_date}'
"""

report = pd.read_sql(query, conn)

# Show result
print("Aged Inventory Items (Older than 5 Years)")
print(report)
